from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://djshaggi:Djshaggi@firstcluster.baej2.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))

db=client['office']
coll=db['workers']

qr={}
no=input('Enter Id: ')
qr["_id"]=no

ch={}
salary=input('Enter new salary: ')
ch['salary']=salary

upd={"$set":ch}
coll.update_one(qr,upd)
print('Doccument updated Sucessfully')

for doc in coll.find(qr):
    print(doc)
    print()