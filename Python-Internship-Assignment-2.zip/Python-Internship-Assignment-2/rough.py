db.workers.insert_one({
    "ID":"01",
    "empnm":"Rohit Sharma",
    "dept":"Development",
    "post":"Programer",
    "city":"Mumbai",
    "salary":500000,
    "mobile":3232323232,
    "email":"rsharm@outlook.com"
})

print('Successfully Inserted')