from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://djshaggi:Djshaggi@firstcluster.baej2.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))

db=client['office']
coll=db['workers']

qr={}
no=input('Enter Id: ')
qr["_id"]=no

ct={}
ty=input('Enter New City: ')
ct["city"]=ty

dep={}
mt=input('Enter New Department: ')
dep["dept"]=mt

updd={"$set":dep}
upd={"$set":ct}
coll.update_many(qr,upd)
coll.update_many(qr,updd)
print('Doccument updated Sucessfully')
