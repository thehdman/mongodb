from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://djshaggi:Djshaggi@firstcluster.baej2.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))

db=client['office']
coll=db['workers']

ch={}
sal=input('Enter salary: ')
ch['salary']=sal

for doc in coll.find({"salary" : { '$gt' : sal }} ):
    print(doc)
    print()

	