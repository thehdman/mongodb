from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://djshaggi:Djshaggi@firstcluster.baej2.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))

db=client['office']
coll=db['workers']

qr={}
no=input('Enter Id: ')
qr["_id"]=no

for doc in coll.find(qr):
    print(doc)
    print()

db.exworkers.insert_one(doc)
print('Data added sucessfully')

db.workers.delete_one(doc)
print('Data deleted sucessfully')

