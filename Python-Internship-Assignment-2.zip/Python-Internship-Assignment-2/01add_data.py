from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://djshaggi:Djshaggi@firstcluster.baej2.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))


db=client['office']
coll=db['workers']

Id=input('Enter id: ')
nm=input('Enter employee name: ')
dept=input('Enter department: ')
post=input('Enter post: ')
city=input('Enter city: ')
sal=int(input('Enter salary: '))
mob=int(input('Enter mobile number: '))
eml=input('Enter email: ')

dic={}
dic["_id"]=Id
dic["empnm"]=nm
dic["dept"]=dept
dic["post"]=post
dic["city"]=city
dic["salary"]=sal
dic["mobile"]=mob
dic["email"]=eml

db.workers.insert_one(dic)

print('Data added sucessfully')
